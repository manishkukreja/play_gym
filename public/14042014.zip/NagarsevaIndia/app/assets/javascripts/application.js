// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or vendor/assets/javascripts of plugins, if any, can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file.
//
// Read Sprockets README (https://github.com/sstephenson/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery
//= require jquery_ujs
//= require jquery.min.js
//= require cufon-yui.js
//= require Akzidenz-Grotesk_BQ_500-Akzidenz-Grotesk_BQ_500-Akzidenz-Grotesk_BQ_italic_700.font.js
//= require FontSoupGerman_700.font.js
//= require Gotham_Rounded_Medium_350.font.js

Cufon.replace('.logo h1', {fontFamily: 'FontSoupGerman'});
Cufon.replace('.logo span', {fontFamily: 'Gotham Rounded Medium'});
Cufon.replace('h2 strong', {fontFamily: 'Akzidenz-Grotesk BQ'});
Cufon.replace('h2 span', {fontFamily: 'Akzidenz-Grotesk BQ'});