NagarsevaIndia::Application.routes.draw do
  root 'welcome#index'
end
