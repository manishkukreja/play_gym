# Be sure to restart your server when you modify this file.

NagarsevaIndia::Application.config.session_store :cookie_store, key: '_NagarsevaIndia_session'
